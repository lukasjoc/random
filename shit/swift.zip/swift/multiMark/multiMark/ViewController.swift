//
//  ViewController.swift
//  multiMark
//
//  Created by Lukas Jocham on 04.10.19.
//  Copyright © 2019 Lukas Jocham. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var textView: UITextView!
    var additiona
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

